package com.cdac.service;

public interface CompanyStateService {

	public double getProfitOrLoss(String district, String month);

}
