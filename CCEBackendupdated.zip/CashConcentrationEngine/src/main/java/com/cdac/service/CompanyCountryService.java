package com.cdac.service;

public interface CompanyCountryService {
	
	public double getProfitOrLossByMonth(String state,String month);


}
