package com.cdac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CashConcentrationEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(CashConcentrationEngineApplication.class, args);
		System.out.println("Development server ran successfully...!");
	}

}
