package com.cdac.entity;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;

@Table
@Entity
public class Company {

	@Id
	@Column(name = "CompanyID")
	private String companyId;

	@Column(name = "CompanyName")
	private String companyName;
    
	
	@Column(name = "DataAddedDate")
	private String dataAddedDate;

	@Column(name = "Total_Monthly_Revenue")
	private double totalMonthlyRevenue;

	@Column(name = "Total_Monthly_Salary")
	private double totalMonthlySalaries;

	@Column(name = "Total_Monthly_Allowance")
	private double totalMonthlyAllowances;

	@Column(name = "Monthly_Budget")
	private double budget;

	public Company() {

	}

	public Company(String companyId, String companyName, String dataAddedDate, double totalMonthlyRevenue,
			double totalMonthlySalaries, double totalMonthlyAllowances, double budget) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.dataAddedDate = dataAddedDate;
		this.totalMonthlyRevenue = totalMonthlyRevenue;
		this.totalMonthlySalaries = totalMonthlySalaries;
		this.totalMonthlyAllowances = totalMonthlyAllowances;
		this.budget = budget;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDataAdded() {
		return dataAddedDate;
	}

	public void setDataAddedDate(String dataAddedDate) {
		this.dataAddedDate = dataAddedDate;
	}

	public double getTotalMonthlyRevenue() {
		return totalMonthlyRevenue;
	}

	public void setTotalMonthlyRevenue(double totalMonthlyRevenue) {
		this.totalMonthlyRevenue = totalMonthlyRevenue;
	}

	public double getTotalMonthlySalaries() {
		return totalMonthlySalaries;
	}

	public void setTotalMonthlySalaries(double totalMonthlySalaries) {
		this.totalMonthlySalaries = totalMonthlySalaries;
	}

	public double getTotalMonthlyAllowances() {
		return totalMonthlyAllowances;
	}

	public void setTotalMonthlyAllowances(double totalMonthlyAllowances) {
		this.totalMonthlyAllowances = totalMonthlyAllowances;
	}

	public double getBudget() {
		return budget;
	}

	public void setBudget(double budget) {
		this.budget = budget;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", dataAddedDate=" + dataAddedDate
				+ ", totalMonthlyRevenue=" + totalMonthlyRevenue + ", totalMonthlySalaries=" + totalMonthlySalaries
				+ ", totalMonthlyAllowances=" + totalMonthlyAllowances + ", budget=" + budget + "]";
	}

}
