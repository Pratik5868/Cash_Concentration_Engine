package com.CDAC_CCE.CCE.Security.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.CDAC_CCE.CCE.Security.User;
import com.CDAC_CCE.CCE.Security.UserImplementation.UserImplementation;

@RestController
public class UserController {

@Autowired
private UserImplementation userImpl;	

@PostMapping("register")
public User registerUser(@RequestBody User user) {
	return userImpl.registerUser(user);
}

@DeleteMapping("/delete/{UserId}")
public void deleteUser(@PathVariable int UserId) {
	userImpl.deleteUser(UserId);
	
}

@PutMapping("/update/{UserId}")
public User updateUser( @RequestBody User user ,@PathVariable User UserId) {
	return userImpl.updateUser(user);
}

	
}
