package com.CDAC_CCE.CCE.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CDAC_CCE.CCE.entity.Company;

public interface CountryRepository extends JpaRepository<Company,String> {

	public List<Company> findByStateName(String stateName);

}
