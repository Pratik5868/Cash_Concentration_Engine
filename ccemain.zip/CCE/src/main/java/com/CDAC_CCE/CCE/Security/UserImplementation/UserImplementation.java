package com.CDAC_CCE.CCE.Security.UserImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CDAC_CCE.CCE.Security.User;
import com.CDAC_CCE.CCE.Security.Repository.UserRepository;


@Service
public class UserImplementation {

@Autowired	
private	UserRepository userRepo;


public User registerUser(User user) {
	
	return userRepo.save(user);
}


public void deleteUser(int UserId) {
	userRepo.deleteById(UserId);
	
}


public User updateUser(User user) {
	
	return userRepo.save(user);
} 
	




}
