package com.CDAC_CCE.CCE.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.CDAC_CCE.CCE.Repository.StateRepository;
import com.CDAC_CCE.CCE.Service.StateService;
import com.CDAC_CCE.CCE.entity.Company;

@CrossOrigin(origins ="http://localhost:3000")
@RestController
public class StateController {
    
	@Autowired
	private StateService stateService;

	@RequestMapping(value="getByStateName/{stateName}", method = RequestMethod.GET)
	public List<Company> getByStateName(@PathVariable String stateName){
		
		return stateService.getByStateName(stateName);
	}
     
	@GetMapping("/getByDistrictName/{districtName}")
	public List<Company> getByDistrictName(@PathVariable String districtName){
		
		return stateService.getByDistrictName(districtName);
	}


	@GetMapping("/getProfitLoss")
	public double ProfitOrLoss(@RequestParam String districtName , @RequestParam String month ) {
		
		return stateService.getProfitOrLoss(districtName, month);
	}
	
}
