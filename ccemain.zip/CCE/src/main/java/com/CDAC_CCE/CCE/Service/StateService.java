package com.CDAC_CCE.CCE.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CDAC_CCE.CCE.Repository.StateRepository;
import com.CDAC_CCE.CCE.entity.Company;


@Service
public class StateService {

@Autowired
private StateRepository	stateRepo;



public List<Company> getByStateName(String stateName) {

	return stateRepo.findByStateName(stateName);
	
}

public List<Company> getByDistrictName(String districtName){
	
	return stateRepo.findByDistrictName(districtName);
}

public double  getProfitOrLoss(String districtName , String month ) {

	ArrayList<Company> company =(ArrayList<Company>) getByDistrictName(districtName); 
	System.out.println(company);
	
	
		for(Company comp : company) {
		if(comp.getMonth().equals(month)) {
		
		double remainingMonthlyRevenue =comp.getTotalMonthlyRevenue()
				-(comp.getTotalMonthlyAllowances()+comp.getTotalMonthlySalaries());
		
		if(remainingMonthlyRevenue >= comp.getBudget()) {
			double profit= remainingMonthlyRevenue - comp.getBudget();
			return profit;
		}
		else {
			double loss= comp.getBudget() - remainingMonthlyRevenue;
			return loss;
		}
		
		
		}
		
		
		}
		return 0;
	
}

/*
 * public double getStateLevelProfitOrLoss(String stateName ,String month) {
 * ArrayList<Company> company =(ArrayList<Company>)
 * getByDistrictName(stateName); System.out.println(company);
 * 
 * 
 * }
 */

	

}
