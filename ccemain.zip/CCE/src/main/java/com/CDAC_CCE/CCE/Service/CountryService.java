package com.CDAC_CCE.CCE.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CDAC_CCE.CCE.Repository.CountryRepository;
import com.CDAC_CCE.CCE.entity.Company;

@Service
public class CountryService {

	@Autowired
	private CountryRepository countryRepo;
	
	public List<Company> getByStateName(String stateName){
		return countryRepo.findByStateName(stateName);
	}
	
}
