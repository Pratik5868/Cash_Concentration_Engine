package com.CDAC_CCE.CCE.Security;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="User_Details")
public class User {

	@Id
	private int UserId;
	
	private String UserName;
	
	private String Password;

	
	private String Role;
	
	
	public User() {
		
	}

	public User(int userId, String userName, String password, String role) {
		super();
		UserId = userId;
		UserName = userName;
		Password = password;
	
		Role = role;
	}

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	@Override
	public String toString() {
		return "User [UserId=" + UserId + ", UserName=" + UserName + ", Password=" + Password + ", Role=" + Role + "]";
	}

	
	
	
	
	
	
}
