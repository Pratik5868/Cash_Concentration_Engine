package com.CDAC_CCE.CCE.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CDAC_CCE.CCE.Repository.StateRepository;
import com.cdac.entity.Company;


@Service
public class StateService {

@Autowired
private StateRepository	stateRepo;

public List<Company> getByStateName(String stateName) {

	return stateRepo.findByStateName(stateName);
	
}

public List<Company> getByDistrictName(String districtName){
	
	return stateRepo.findByDistrictName(districtName);
}
}
