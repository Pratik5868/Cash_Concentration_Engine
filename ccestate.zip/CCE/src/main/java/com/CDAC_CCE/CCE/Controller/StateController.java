package com.CDAC_CCE.CCE.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.CDAC_CCE.CCE.Repository.StateRepository;
import com.CDAC_CCE.CCE.Service.StateService;
import com.cdac.entity.Company;

@RestController
public class StateController {
    
	@Autowired
	private StateService stateService;

	@GetMapping("/getByStateName/{stateName}")
	public List<Company> getByStateName(@PathVariable String state){
		
		return stateService.getByStateName(state);
	}
     
	@GetMapping("/getByDistrictName/{districtName}")
	public List<Company> getByDistrictName(@PathVariable String district){
		
		return stateService.getByDistrictName(district);
	}

	
}
