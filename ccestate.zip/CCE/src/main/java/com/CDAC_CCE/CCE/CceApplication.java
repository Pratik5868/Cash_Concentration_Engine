package com.CDAC_CCE.CCE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CceApplication.class, args);
	}

}
